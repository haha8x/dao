<a href="#" class="btn btn-icon btn-danger deleteDialog" data-toggle="tooltip" data-section="{{ route('users-supers.destroy', $item->id) }}" role="button" data-original-title="{{ trans('core/base::tables.delete_entry') }}" >
    <i class="fa fa-trash"></i>
</a>