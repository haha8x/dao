<?php

return [
    [
        'name' => 'Catalogs',
        'flag' => 'catalog.index',
    ],
    [
        'name' => 'Catalog positions',
        'flag' => 'catalog-position.index',
        'parent_flag' => 'catalog.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'catalog-position.create',
        'parent_flag' => 'catalog-position.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'catalog-position.edit',
        'parent_flag' => 'catalog-position.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'catalog-position.destroy',
        'parent_flag' => 'catalog-position.index',
    ],
    [
        'name' => 'Catalog zones',
        'flag' => 'catalog-zone.index',
        'parent_flag' => 'catalog.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'catalog-zone.create',
        'parent_flag' => 'catalog-zone.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'catalog-zone.edit',
        'parent_flag' => 'catalog-zone.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'catalog-zone.destroy',
        'parent_flag' => 'catalog-zone.index',
    ],
    [
        'name' => 'Catalog branches',
        'flag' => 'catalog-branch.index',
        'parent_flag' => 'catalog.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'catalog-branch.create',
        'parent_flag' => 'catalog-branch.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'catalog-branch.edit',
        'parent_flag' => 'catalog-branch.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'catalog-branch.destroy',
        'parent_flag' => 'catalog-branch.index',
    ],
];
