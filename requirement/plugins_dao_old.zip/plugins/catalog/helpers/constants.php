<?php

if (!defined('CATALOG_BRANCH_MODULE_SCREEN_NAME')) {
    define('CATALOG_BRANCH_MODULE_SCREEN_NAME', 'catalog-branch');
}
if (!defined('CATALOG_POSITION_MODULE_SCREEN_NAME')) {
    define('CATALOG_POSITION_MODULE_SCREEN_NAME', 'catalog-position');
}
if (!defined('CATALOG_ZONE_MODULE_SCREEN_NAME')) {
    define('CATALOG_ZONE_MODULE_SCREEN_NAME', 'catalog-zone');
}
