<?php

return [
    'name'   => 'Danh mục Vùng',
    'create' => 'Tạo Vùng',
    'edit'   => 'Sửa Vùng',
];
