<?php

return [
    'name'   => 'Danh mục chi nhánh',
    'create' => 'Tạo chi nhánh',
    'edit'   => 'Sửa chi nhánh',
];
