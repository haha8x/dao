<?php

return [
    'name'   => 'Danh mục Chức danh',
    'create' => 'Tạo chức danh',
    'edit'   => 'Sửa chức danh',
];
