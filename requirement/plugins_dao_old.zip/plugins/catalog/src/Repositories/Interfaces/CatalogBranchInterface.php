<?php

namespace Botble\Catalog\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CatalogBranchInterface extends RepositoryInterface
{
}
