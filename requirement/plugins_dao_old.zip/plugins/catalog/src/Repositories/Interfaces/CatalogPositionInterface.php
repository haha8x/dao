<?php

namespace Botble\Catalog\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CatalogPositionInterface extends RepositoryInterface
{
}
