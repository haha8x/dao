<?php

namespace Botble\Catalog\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Catalog\Repositories\Interfaces\CatalogZoneInterface;

class CatalogZoneCacheDecorator extends CacheAbstractDecorator implements CatalogZoneInterface
{

}
