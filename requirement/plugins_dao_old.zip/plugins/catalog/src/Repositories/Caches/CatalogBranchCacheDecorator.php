<?php

namespace Botble\Catalog\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Catalog\Repositories\Interfaces\CatalogBranchInterface;

class CatalogBranchCacheDecorator extends CacheAbstractDecorator implements CatalogBranchInterface
{

}
