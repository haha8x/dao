<?php

namespace Botble\Catalog\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Catalog\Repositories\Interfaces\CatalogZoneInterface;

class CatalogZoneRepository extends RepositoriesAbstract implements CatalogZoneInterface
{
}
