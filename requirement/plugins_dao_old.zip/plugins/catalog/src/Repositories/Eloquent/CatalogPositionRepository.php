<?php

namespace Botble\Catalog\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Catalog\Repositories\Interfaces\CatalogPositionInterface;

class CatalogPositionRepository extends RepositoriesAbstract implements CatalogPositionInterface
{
}
