<?php

namespace Botble\Catalog\Forms;

use Botble\Base\Forms\FormAbstract;
use Botble\Base\Enums\BaseStatusEnum;
use Botble\Catalog\Http\Requests\CatalogBranchRequest;
use Botble\Catalog\Models\CatalogBranch;

class CatalogBranchForm extends FormAbstract
{

    /**
     * @return mixed|void
     * @throws \Throwable
     */
    public function buildForm()
    {
        $this
            ->setupModel(new CatalogBranch)
            ->setValidatorClass(CatalogBranchRequest::class)
            ->withCustomFields()
            ->add('code', 'text', [
                'label'      => __('Mã chi nhánh'),
                'label_attr' => ['class' => 'control-label required'],
                'attr'       => [
                    'placeholder'  => __('Mã chi nhánh'),
                    'data-counter' => 120,
                ],
            ])
            ->add('name', 'text', [
                'label'      => trans('core/base::forms.name'),
                'label_attr' => ['class' => 'control-label required'],
                'attr'       => [
                    'placeholder'  => trans('core/base::forms.name_placeholder'),
                    'data-counter' => 120,
                ],
            ]);
    }
}
