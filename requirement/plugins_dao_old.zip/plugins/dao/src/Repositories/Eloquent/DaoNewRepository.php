<?php

namespace Botble\Dao\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Dao\Repositories\Interfaces\DaoNewInterface;

class DaoNewRepository extends RepositoriesAbstract implements DaoNewInterface
{
}
