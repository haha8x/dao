<?php

namespace Botble\Dao\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Dao\Repositories\Interfaces\DaoInterface;

class DaoRepository extends RepositoriesAbstract implements DaoInterface
{
}
