<?php

namespace Botble\Dao\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Dao\Repositories\Interfaces\DaoCloseInterface;

class DaoCloseRepository extends RepositoriesAbstract implements DaoCloseInterface
{
}
