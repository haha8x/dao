<?php

namespace Botble\Dao\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Dao\Repositories\Interfaces\DaoUpdateInterface;

class DaoUpdateRepository extends RepositoriesAbstract implements DaoUpdateInterface
{
}
