<?php

namespace Botble\Dao\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Dao\Repositories\Interfaces\DaoTransferInterface;

class DaoTransferRepository extends RepositoriesAbstract implements DaoTransferInterface
{
}
