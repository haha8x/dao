<?php

namespace Botble\Dao\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface DaoTransferInterface extends RepositoryInterface
{
}
