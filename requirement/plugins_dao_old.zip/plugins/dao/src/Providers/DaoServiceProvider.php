<?php

namespace Botble\Dao\Providers;

use Botble\Dao\Models\Dao;
use Illuminate\Support\ServiceProvider;
use Botble\Dao\Repositories\Caches\DaoCacheDecorator;
use Botble\Dao\Repositories\Eloquent\DaoRepository;
use Botble\Dao\Repositories\Interfaces\DaoInterface;
use Botble\Base\Supports\Helper;
use Event;
use Botble\Base\Traits\LoadAndPublishDataTrait;
use Illuminate\Routing\Events\RouteMatched;

class DaoServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    /**
     * @var \Illuminate\Foundation\Application
     */
    protected $app;

    public function register()
    {
        $this->app->bind(DaoInterface::class, function () {
            return new DaoCacheDecorator(new DaoRepository(new Dao));
        });

        $this->app->bind(\Botble\Dao\Repositories\Interfaces\CustomerInterface::class, function () {
            return new \Botble\Dao\Repositories\Caches\CustomerCacheDecorator(
                new \Botble\Dao\Repositories\Eloquent\CustomerRepository(new \Botble\Dao\Models\Customer)
            );
        });

        $this->app->bind(\Botble\Dao\Repositories\Interfaces\DaoNewInterface::class, function () {
            return new \Botble\Dao\Repositories\Caches\DaoNewCacheDecorator(
                new \Botble\Dao\Repositories\Eloquent\DaoNewRepository(new \Botble\Dao\Models\DaoNew)
            );
        });

        $this->app->bind(\Botble\Dao\Repositories\Interfaces\DaoUpdateInterface::class, function () {
            return new \Botble\Dao\Repositories\Caches\DaoUpdateCacheDecorator(
                new \Botble\Dao\Repositories\Eloquent\DaoUpdateRepository(new \Botble\Dao\Models\DaoUpdate)
            );
        });

        $this->app->bind(\Botble\Dao\Repositories\Interfaces\DaoTransferInterface::class, function () {
            return new \Botble\Dao\Repositories\Caches\DaoTransferCacheDecorator(
                new \Botble\Dao\Repositories\Eloquent\DaoTransferRepository(new \Botble\Dao\Models\DaoTransfer)
            );
        });

        $this->app->bind(\Botble\Dao\Repositories\Interfaces\DaoCloseInterface::class, function () {
            return new \Botble\Dao\Repositories\Caches\DaoCloseCacheDecorator(
                new \Botble\Dao\Repositories\Eloquent\DaoCloseRepository(new \Botble\Dao\Models\DaoClose)
            );
        });

        Helper::autoload(__DIR__ . '/../../helpers');
    }

    public function boot()
    {
        $this->setNamespace('plugins/dao')
            ->loadAndPublishConfigurations(['permissions'])
            ->loadMigrations()
            ->loadAndPublishViews()
            ->loadAndPublishTranslations()
            ->loadRoutes(['web']);

        Event::listen(RouteMatched::class, function () {

            dashboard_menu()->registerItem([
                'id'          => 'cms-plugins-dao',
                'priority'    => 5,
                'parent_id'   => null,
                'name'        => __('Quản lý DAO'),
                'icon'        => 'fa fa-list',
                'url'         => route('dao.index'),
                'permissions' => ['dao.index'],
            ])
            ->registerItem([
                'id'          => 'cms-plugins-dao-new',
                'priority'    => 0,
                'parent_id'   => 'cms-plugins-dao',
                'name'        => __('Yêu cầu cấp mới mã DAO'),
                'icon'        => null,
                'url'         => route('dao-new.index'),
                'permissions' => ['dao-new.index'],
            ])->registerItem([
                'id'          => 'cms-plugins-dao-update',
                'priority'    => 0,
                'parent_id'   => 'cms-plugins-dao',
                'name'        => __('Yêu cầu cập nhật thông tin mã DAO'),
                'icon'        => null,
                'url'         => route('dao-update.index'),
                'permissions' => ['dao-update.index'],
            ])->registerItem([
                'id'          => 'cms-plugins-dao-transfer',
                'priority'    => 0,
                'parent_id'   => 'cms-plugins-dao',
                'name'        => __('Yêu cầu chuyển mã DAO'),
                'icon'        => null,
                'url'         => route('dao-transfer.index'),
                'permissions' => ['dao-transfer.index'],
            ])->registerItem([
                'id'          => 'cms-plugins-dao-close',
                'priority'    => 0,
                'parent_id'   => 'cms-plugins-dao',
                'name'        => __('Yêu cầu đóng mã DAO'),
                'icon'        => null,
                'url'         => route('dao-close.index'),
                'permissions' => ['dao-close.index'],
            ]);

            dashboard_menu()->registerItem([
                'id'          => 'cms-plugins-customer',
                'priority'    => 5,
                'parent_id'   => null,
                'name'        => __('Danh sách khách hàng'),
                'icon'        => 'fa fa-list',
                'url'         => route('customer.index'),
                'permissions' => ['customer.index'],
            ]);
        });

        $this->app->register(HookServiceProvider::class);
    }
}
