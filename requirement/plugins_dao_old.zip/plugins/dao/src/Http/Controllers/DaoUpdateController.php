<?php

namespace Botble\Dao\Http\Controllers;

use Botble\Base\Events\BeforeEditContentEvent;
use Botble\Dao\Http\Requests\DaoUpdateRequest;
use Botble\Dao\Repositories\Interfaces\DaoUpdateInterface;
use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Exception;
use Botble\Dao\Tables\DaoUpdateTable;
use Botble\Base\Events\CreatedContentEvent;
use Botble\Base\Events\DeletedContentEvent;
use Botble\Base\Events\UpdatedContentEvent;
use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Dao\Forms\DaoUpdateForm;
use Botble\Base\Forms\FormBuilder;

class DaoUpdateController extends BaseController
{
    /**
     * @var DaoUpdateInterface
     */
    protected $daoUpdateRepository;

    /**
     * DaoUpdateController constructor.
     * @param DaoUpdateInterface $daoUpdateRepository
     */
    public function __construct(DaoUpdateInterface $daoUpdateRepository)
    {
        $this->daoUpdateRepository = $daoUpdateRepository;
    }

    /**
     * @param DaoUpdateTable $dataTable
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Throwable
     */
    public function index(DaoUpdateTable $table)
    {

        page_title()->setTitle(trans('plugins/dao::dao-update.name'));

        return $table->renderTable();
    }

    /**
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function create(FormBuilder $formBuilder)
    {
        page_title()->setTitle(trans('plugins/dao::dao-update.create'));

        return $formBuilder->create(DaoUpdateForm::class)->renderForm();
    }

    /**
     * Insert new DaoUpdate into database
     *
     * @param DaoUpdateRequest $request
     * @return BaseHttpResponse
     */
    public function store(DaoUpdateRequest $request, BaseHttpResponse $response)
    {
        $daoUpdate = $this->daoUpdateRepository->createOrUpdate($request->input());

        event(new CreatedContentEvent(DAO_UPDATE_MODULE_SCREEN_NAME, $request, $daoUpdate));

        return $response
            ->setPreviousUrl(route('dao-update.index'))
            ->setNextUrl(route('dao-update.edit', $daoUpdate->id))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    /**
     * Show edit form
     *
     * @param $id
     * @param Request $request
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function edit($id, FormBuilder $formBuilder, Request $request)
    {
        $daoUpdate = $this->daoUpdateRepository->findOrFail($id);

        event(new BeforeEditContentEvent($request, $daoUpdate));

        page_title()->setTitle(trans('plugins/dao::dao-update.edit') . ' "' . $daoUpdate->name . '"');

        return $formBuilder->create(DaoUpdateForm::class, ['model' => $daoUpdate])->renderForm();
    }

    /**
     * @param $id
     * @param DaoUpdateRequest $request
     * @return BaseHttpResponse
     */
    public function update($id, DaoUpdateRequest $request, BaseHttpResponse $response)
    {
        $daoUpdate = $this->daoUpdateRepository->findOrFail($id);

        $daoUpdate->fill($request->input());

        $this->daoUpdateRepository->createOrUpdate($daoUpdate);

        event(new UpdatedContentEvent(DAO_UPDATE_MODULE_SCREEN_NAME, $request, $daoUpdate));

        return $response
            ->setPreviousUrl(route('dao-update.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    /**
     * @param $id
     * @param Request $request
     * @return BaseHttpResponse
     */
    public function destroy(Request $request, $id, BaseHttpResponse $response)
    {
        try {
            $daoUpdate = $this->daoUpdateRepository->findOrFail($id);

            $this->daoUpdateRepository->delete($daoUpdate);

            event(new DeletedContentEvent(DAO_UPDATE_MODULE_SCREEN_NAME, $request, $daoUpdate));

            return $response->setMessage(trans('core/base::notices.delete_success_message'));
        } catch (Exception $exception) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.cannot_delete'));
        }
    }

    /**
     * @param Request $request
     * @param BaseHttpResponse $response
     * @return BaseHttpResponse
     * @throws Exception
     */
    public function deletes(Request $request, BaseHttpResponse $response)
    {
        $ids = $request->input('ids');
        if (empty($ids)) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.no_select'));
        }

        foreach ($ids as $id) {
            $daoUpdate = $this->daoUpdateRepository->findOrFail($id);
            $this->daoUpdateRepository->delete($daoUpdate);
            event(new DeletedContentEvent(DAO_UPDATE_MODULE_SCREEN_NAME, $request, $daoUpdate));
        }

        return $response->setMessage(trans('core/base::notices.delete_success_message'));
    }
}
