<?php

namespace Botble\Dao\Http\Controllers;

use Botble\Base\Events\BeforeEditContentEvent;
use Botble\Dao\Http\Requests\DaoTransferRequest;
use Botble\Dao\Repositories\Interfaces\DaoTransferInterface;
use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Exception;
use Botble\Dao\Tables\DaoTransferTable;
use Botble\Base\Events\CreatedContentEvent;
use Botble\Base\Events\DeletedContentEvent;
use Botble\Base\Events\UpdatedContentEvent;
use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Dao\Forms\DaoTransferForm;
use Botble\Base\Forms\FormBuilder;

class DaoTransferController extends BaseController
{
    /**
     * @var DaoTransferInterface
     */
    protected $daoTransferRepository;

    /**
     * DaoTransferController constructor.
     * @param DaoTransferInterface $daoTransferRepository
     */
    public function __construct(DaoTransferInterface $daoTransferRepository)
    {
        $this->daoTransferRepository = $daoTransferRepository;
    }

    /**
     * @param DaoTransferTable $dataTable
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Throwable
     */
    public function index(DaoTransferTable $table)
    {

        page_title()->setTitle(trans('plugins/dao::dao-transfer.name'));

        return $table->renderTable();
    }

    /**
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function create(FormBuilder $formBuilder)
    {
        page_title()->setTitle(trans('plugins/dao::dao-transfer.create'));

        return $formBuilder->create(DaoTransferForm::class)->renderForm();
    }

    /**
     * Insert new DaoTransfer into database
     *
     * @param DaoTransferRequest $request
     * @return BaseHttpResponse
     */
    public function store(DaoTransferRequest $request, BaseHttpResponse $response)
    {
        $daoTransfer = $this->daoTransferRepository->createOrUpdate($request->input());

        event(new CreatedContentEvent(DAO_TRANSFER_MODULE_SCREEN_NAME, $request, $daoTransfer));

        return $response
            ->setPreviousUrl(route('dao-transfer.index'))
            ->setNextUrl(route('dao-transfer.edit', $daoTransfer->id))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    /**
     * Show edit form
     *
     * @param $id
     * @param Request $request
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function edit($id, FormBuilder $formBuilder, Request $request)
    {
        $daoTransfer = $this->daoTransferRepository->findOrFail($id);

        event(new BeforeEditContentEvent($request, $daoTransfer));

        page_title()->setTitle(trans('plugins/dao::dao-transfer.edit') . ' "' . $daoTransfer->name . '"');

        return $formBuilder->create(DaoTransferForm::class, ['model' => $daoTransfer])->renderForm();
    }

    /**
     * @param $id
     * @param DaoTransferRequest $request
     * @return BaseHttpResponse
     */
    public function update($id, DaoTransferRequest $request, BaseHttpResponse $response)
    {
        $daoTransfer = $this->daoTransferRepository->findOrFail($id);

        $daoTransfer->fill($request->input());

        $this->daoTransferRepository->createOrUpdate($daoTransfer);

        event(new UpdatedContentEvent(DAO_TRANSFER_MODULE_SCREEN_NAME, $request, $daoTransfer));

        return $response
            ->setPreviousUrl(route('dao-transfer.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    /**
     * @param $id
     * @param Request $request
     * @return BaseHttpResponse
     */
    public function destroy(Request $request, $id, BaseHttpResponse $response)
    {
        try {
            $daoTransfer = $this->daoTransferRepository->findOrFail($id);

            $this->daoTransferRepository->delete($daoTransfer);

            event(new DeletedContentEvent(DAO_TRANSFER_MODULE_SCREEN_NAME, $request, $daoTransfer));

            return $response->setMessage(trans('core/base::notices.delete_success_message'));
        } catch (Exception $exception) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.cannot_delete'));
        }
    }

    /**
     * @param Request $request
     * @param BaseHttpResponse $response
     * @return BaseHttpResponse
     * @throws Exception
     */
    public function deletes(Request $request, BaseHttpResponse $response)
    {
        $ids = $request->input('ids');
        if (empty($ids)) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.no_select'));
        }

        foreach ($ids as $id) {
            $daoTransfer = $this->daoTransferRepository->findOrFail($id);
            $this->daoTransferRepository->delete($daoTransfer);
            event(new DeletedContentEvent(DAO_TRANSFER_MODULE_SCREEN_NAME, $request, $daoTransfer));
        }

        return $response->setMessage(trans('core/base::notices.delete_success_message'));
    }
}
