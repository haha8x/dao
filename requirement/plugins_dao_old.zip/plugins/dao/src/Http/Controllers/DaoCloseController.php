<?php

namespace Botble\Dao\Http\Controllers;

use Botble\Base\Events\BeforeEditContentEvent;
use Botble\Dao\Http\Requests\DaoCloseRequest;
use Botble\Dao\Repositories\Interfaces\DaoCloseInterface;
use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Exception;
use Botble\Dao\Tables\DaoCloseTable;
use Botble\Base\Events\CreatedContentEvent;
use Botble\Base\Events\DeletedContentEvent;
use Botble\Base\Events\UpdatedContentEvent;
use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Dao\Forms\DaoCloseForm;
use Botble\Base\Forms\FormBuilder;

class DaoCloseController extends BaseController
{
    /**
     * @var DaoCloseInterface
     */
    protected $daoCloseRepository;

    /**
     * DaoCloseController constructor.
     * @param DaoCloseInterface $daoCloseRepository
     */
    public function __construct(DaoCloseInterface $daoCloseRepository)
    {
        $this->daoCloseRepository = $daoCloseRepository;
    }

    /**
     * @param DaoCloseTable $dataTable
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Throwable
     */
    public function index(DaoCloseTable $table)
    {

        page_title()->setTitle(trans('plugins/dao::dao-close.name'));

        return $table->renderTable();
    }

    /**
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function create(FormBuilder $formBuilder)
    {
        page_title()->setTitle(trans('plugins/dao::dao-close.create'));

        return $formBuilder->create(DaoCloseForm::class)->renderForm();
    }

    /**
     * Insert new DaoClose into database
     *
     * @param DaoCloseRequest $request
     * @return BaseHttpResponse
     */
    public function store(DaoCloseRequest $request, BaseHttpResponse $response)
    {
        $daoClose = $this->daoCloseRepository->createOrUpdate($request->input());

        event(new CreatedContentEvent(DAO_CLOSE_MODULE_SCREEN_NAME, $request, $daoClose));

        return $response
            ->setPreviousUrl(route('dao-close.index'))
            ->setNextUrl(route('dao-close.edit', $daoClose->id))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    /**
     * Show edit form
     *
     * @param $id
     * @param Request $request
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function edit($id, FormBuilder $formBuilder, Request $request)
    {
        $daoClose = $this->daoCloseRepository->findOrFail($id);

        event(new BeforeEditContentEvent($request, $daoClose));

        page_title()->setTitle(trans('plugins/dao::dao-close.edit') . ' "' . $daoClose->name . '"');

        return $formBuilder->create(DaoCloseForm::class, ['model' => $daoClose])->renderForm();
    }

    /**
     * @param $id
     * @param DaoCloseRequest $request
     * @return BaseHttpResponse
     */
    public function update($id, DaoCloseRequest $request, BaseHttpResponse $response)
    {
        $daoClose = $this->daoCloseRepository->findOrFail($id);

        $daoClose->fill($request->input());

        $this->daoCloseRepository->createOrUpdate($daoClose);

        event(new UpdatedContentEvent(DAO_CLOSE_MODULE_SCREEN_NAME, $request, $daoClose));

        return $response
            ->setPreviousUrl(route('dao-close.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    /**
     * @param $id
     * @param Request $request
     * @return BaseHttpResponse
     */
    public function destroy(Request $request, $id, BaseHttpResponse $response)
    {
        try {
            $daoClose = $this->daoCloseRepository->findOrFail($id);

            $this->daoCloseRepository->delete($daoClose);

            event(new DeletedContentEvent(DAO_CLOSE_MODULE_SCREEN_NAME, $request, $daoClose));

            return $response->setMessage(trans('core/base::notices.delete_success_message'));
        } catch (Exception $exception) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.cannot_delete'));
        }
    }

    /**
     * @param Request $request
     * @param BaseHttpResponse $response
     * @return BaseHttpResponse
     * @throws Exception
     */
    public function deletes(Request $request, BaseHttpResponse $response)
    {
        $ids = $request->input('ids');
        if (empty($ids)) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.no_select'));
        }

        foreach ($ids as $id) {
            $daoClose = $this->daoCloseRepository->findOrFail($id);
            $this->daoCloseRepository->delete($daoClose);
            event(new DeletedContentEvent(DAO_CLOSE_MODULE_SCREEN_NAME, $request, $daoClose));
        }

        return $response->setMessage(trans('core/base::notices.delete_success_message'));
    }
}
