<?php

namespace Botble\Dao\Http\Controllers;

use Botble\Base\Events\BeforeEditContentEvent;
use Botble\Dao\Http\Requests\DaoNewRequest;
use Botble\Dao\Repositories\Interfaces\DaoNewInterface;
use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Exception;
use Botble\Dao\Tables\DaoNewTable;
use Botble\Base\Events\CreatedContentEvent;
use Botble\Base\Events\DeletedContentEvent;
use Botble\Base\Events\UpdatedContentEvent;
use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Dao\Forms\DaoNewForm;
use Botble\Base\Forms\FormBuilder;

class DaoNewController extends BaseController
{
    /**
     * @var DaoNewInterface
     */
    protected $daoNewRepository;

    /**
     * DaoNewController constructor.
     * @param DaoNewInterface $daoNewRepository
     */
    public function __construct(DaoNewInterface $daoNewRepository)
    {
        $this->daoNewRepository = $daoNewRepository;
    }

    /**
     * @param DaoNewTable $dataTable
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Throwable
     */
    public function index(DaoNewTable $table)
    {

        page_title()->setTitle(trans('plugins/dao::dao-new.name'));

        return $table->renderTable();
    }

    /**
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function create(FormBuilder $formBuilder)
    {
        page_title()->setTitle(trans('plugins/dao::dao-new.create'));

        return $formBuilder->create(DaoNewForm::class)->renderForm();
    }

    /**
     * Insert new DaoNew into database
     *
     * @param DaoNewRequest $request
     * @return BaseHttpResponse
     */
    public function store(DaoNewRequest $request, BaseHttpResponse $response)
    {
        $daoNew = $this->daoNewRepository->createOrUpdate($request->input());

        event(new CreatedContentEvent(DAO_NEW_MODULE_SCREEN_NAME, $request, $daoNew));

        return $response
            ->setPreviousUrl(route('dao-new.index'))
            ->setNextUrl(route('dao-new.edit', $daoNew->id))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    /**
     * Show edit form
     *
     * @param $id
     * @param Request $request
     * @param FormBuilder $formBuilder
     * @return string
     */
    public function edit($id, FormBuilder $formBuilder, Request $request)
    {
        $daoNew = $this->daoNewRepository->findOrFail($id);

        event(new BeforeEditContentEvent($request, $daoNew));

        page_title()->setTitle(trans('plugins/dao::dao-new.edit') . ' "' . $daoNew->name . '"');

        return $formBuilder->create(DaoNewForm::class, ['model' => $daoNew])->renderForm();
    }

    /**
     * @param $id
     * @param DaoNewRequest $request
     * @return BaseHttpResponse
     */
    public function update($id, DaoNewRequest $request, BaseHttpResponse $response)
    {
        $daoNew = $this->daoNewRepository->findOrFail($id);

        $daoNew->fill($request->input());

        $this->daoNewRepository->createOrUpdate($daoNew);

        event(new UpdatedContentEvent(DAO_NEW_MODULE_SCREEN_NAME, $request, $daoNew));

        return $response
            ->setPreviousUrl(route('dao-new.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    /**
     * @param $id
     * @param Request $request
     * @return BaseHttpResponse
     */
    public function destroy(Request $request, $id, BaseHttpResponse $response)
    {
        try {
            $daoNew = $this->daoNewRepository->findOrFail($id);

            $this->daoNewRepository->delete($daoNew);

            event(new DeletedContentEvent(DAO_NEW_MODULE_SCREEN_NAME, $request, $daoNew));

            return $response->setMessage(trans('core/base::notices.delete_success_message'));
        } catch (Exception $exception) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.cannot_delete'));
        }
    }

    /**
     * @param Request $request
     * @param BaseHttpResponse $response
     * @return BaseHttpResponse
     * @throws Exception
     */
    public function deletes(Request $request, BaseHttpResponse $response)
    {
        $ids = $request->input('ids');
        if (empty($ids)) {
            return $response
                ->setError()
                ->setMessage(trans('core/base::notices.no_select'));
        }

        foreach ($ids as $id) {
            $daoNew = $this->daoNewRepository->findOrFail($id);
            $this->daoNewRepository->delete($daoNew);
            event(new DeletedContentEvent(DAO_NEW_MODULE_SCREEN_NAME, $request, $daoNew));
        }

        return $response->setMessage(trans('core/base::notices.delete_success_message'));
    }
}
