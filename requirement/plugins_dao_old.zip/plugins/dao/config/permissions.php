<?php

return [
    [
        'name' => 'Daos',
        'flag' => 'dao.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'dao.create',
        'parent_flag' => 'dao.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'dao.edit',
        'parent_flag' => 'dao.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'dao.destroy',
        'parent_flag' => 'dao.index',
    ],
    [
        'name' => 'Dao news',
        'flag' => 'dao-new.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'dao-new.create',
        'parent_flag' => 'dao-new.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'dao-new.edit',
        'parent_flag' => 'dao-new.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'dao-new.destroy',
        'parent_flag' => 'dao-new.index',
    ],
    [
        'name' => 'Dao updates',
        'flag' => 'dao-update.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'dao-update.create',
        'parent_flag' => 'dao-update.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'dao-update.edit',
        'parent_flag' => 'dao-update.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'dao-update.destroy',
        'parent_flag' => 'dao-update.index',
    ],
    [
        'name' => 'Dao transfers',
        'flag' => 'dao-transfer.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'dao-transfer.create',
        'parent_flag' => 'dao-transfer.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'dao-transfer.edit',
        'parent_flag' => 'dao-transfer.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'dao-transfer.destroy',
        'parent_flag' => 'dao-transfer.index',
    ],
    [
        'name' => 'Dao closes',
        'flag' => 'dao-close.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'dao-close.create',
        'parent_flag' => 'dao-close.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'dao-close.edit',
        'parent_flag' => 'dao-close.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'dao-close.destroy',
        'parent_flag' => 'dao-close.index',
    ],
    [
        'name' => 'Customers',
        'flag' => 'customer.index',
    ],
    [
        'name'        => 'Create',
        'flag'        => 'customer.create',
        'parent_flag' => 'customer.index',
    ],
    [
        'name'        => 'Edit',
        'flag'        => 'customer.edit',
        'parent_flag' => 'customer.index',
    ],
    [
        'name'        => 'Delete',
        'flag'        => 'customer.destroy',
        'parent_flag' => 'customer.index',
    ],
];
