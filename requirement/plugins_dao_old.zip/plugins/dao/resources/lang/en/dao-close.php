<?php

return [
    'name'   => 'Dao closes',
    'create' => 'New dao close',
    'edit'   => 'Edit dao close',
];
