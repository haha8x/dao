<?php

return [
    'name'   => 'Dao transfers',
    'create' => 'New dao transfer',
    'edit'   => 'Edit dao transfer',
];
