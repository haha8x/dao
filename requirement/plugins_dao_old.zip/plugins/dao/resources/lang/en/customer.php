<?php

return [
    'name'   => 'Customers',
    'create' => 'New customer',
    'edit'   => 'Edit customer',
];
