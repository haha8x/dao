<?php

return [
    'name' => 'Dao',
    'create' => 'New dao',
    'edit' => 'Edit dao',
];
