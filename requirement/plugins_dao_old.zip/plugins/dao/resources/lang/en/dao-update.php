<?php

return [
    'name'   => 'Dao updates',
    'create' => 'New dao update',
    'edit'   => 'Edit dao update',
];
