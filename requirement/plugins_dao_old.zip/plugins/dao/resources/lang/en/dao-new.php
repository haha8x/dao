<?php

return [
    'name'   => 'Dao news',
    'create' => 'New dao new',
    'edit'   => 'Edit dao new',
];
