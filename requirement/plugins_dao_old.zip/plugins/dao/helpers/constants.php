<?php

if (!defined('DAO_MODULE_SCREEN_NAME')) {
    define('DAO_MODULE_SCREEN_NAME', 'dao');
}
if (!defined('CUSTOMER_MODULE_SCREEN_NAME')) {
    define('CUSTOMER_MODULE_SCREEN_NAME', 'customer');
}
if (!defined('DAO_NEW_MODULE_SCREEN_NAME')) {
    define('DAO_NEW_MODULE_SCREEN_NAME', 'dao-new');
}
if (!defined('DAO_UPDATE_MODULE_SCREEN_NAME')) {
    define('DAO_UPDATE_MODULE_SCREEN_NAME', 'dao-update');
}
if (!defined('DAO_TRANSFER_MODULE_SCREEN_NAME')) {
    define('DAO_TRANSFER_MODULE_SCREEN_NAME', 'dao-transfer');
}
if (!defined('DAO_CLOSE_MODULE_SCREEN_NAME')) {
    define('DAO_CLOSE_MODULE_SCREEN_NAME', 'dao-close');
}
