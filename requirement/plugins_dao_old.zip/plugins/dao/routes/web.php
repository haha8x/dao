<?php

Route::group(['namespace' => 'Botble\Dao\Http\Controllers', 'middleware' => 'web'], function () {

    Route::group(['prefix' => config('core.base.general.admin_dir'), 'middleware' => 'auth'], function () {

        Route::group(['prefix' => 'daos', 'as' => 'dao.'], function () {
            Route::resource('', 'DaoController')->parameters(['' => 'dao']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'DaoController@deletes',
                'permission' => 'dao.destroy',
            ]);
        });

        Route::group(['prefix' => 'dao/news', 'as' => 'dao-new.'], function () {
            Route::resource('', 'DaoNewController')->parameters(['' => 'dao-new']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'DaoNewController@deletes',
                'permission' => 'dao-new.destroy',
            ]);
        });

        Route::group(['prefix' => 'dao/updates', 'as' => 'dao-update.'], function () {
            Route::resource('', 'DaoUpdateController')->parameters(['' => 'dao-update']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'DaoUpdateController@deletes',
                'permission' => 'dao-update.destroy',
            ]);
        });

        Route::group(['prefix' => 'dao/transfers', 'as' => 'dao-transfer.'], function () {
            Route::resource('', 'DaoTransferController')->parameters(['' => 'dao-transfer']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'DaoTransferController@deletes',
                'permission' => 'dao-transfer.destroy',
            ]);
        });

        Route::group(['prefix' => 'dao/closes', 'as' => 'dao-close.'], function () {
            Route::resource('', 'DaoCloseController')->parameters(['' => 'dao-close']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'DaoCloseController@deletes',
                'permission' => 'dao-close.destroy',
            ]);
        });

        Route::group(['prefix' => 'customers', 'as' => 'customer.'], function () {
            Route::resource('', 'CustomerController')->parameters(['' => 'customer']);
            Route::delete('items/destroy', [
                'as'         => 'deletes',
                'uses'       => 'CustomerController@deletes',
                'permission' => 'customer.destroy',
            ]);
        });


    });

});
